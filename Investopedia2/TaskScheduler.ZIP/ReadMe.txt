How to "install" the Task Scheduler UDF				2020-11-13
--------------------------------------------------------------------------
This step is mandatory:
* Copy TaskScheduler.au3 into the %ProgramFiles%\AutoIt3\Include, the AutoIt User Includes directory or the directory
  where your script is located

The following steps are optional:

For SciTE integration (user calltips and syntax highlighting)
* Run the User CallTip Manager from SciTE Config tool, tab Other Tools.
  For details please check: http://www.autoitscript.com/wiki/Adding_UDFs_to_AutoIt_and_SciTE

Help files and examples
* Copy the *.htm and the remaining *.au3 files to any directory you like. 
  You can't call the help and example scripts from the AutoIt help at the moment
